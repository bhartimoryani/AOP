package com.infy.utility;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;


@Component
@Aspect
public class LoggingAspect2 {

	

	@Before("execution(* com.infy.service.Trial.m1(..))")
	public void before()  {
		System.out.println("before advise");
	}

	@After("execution(* com.infy.service.Trial.m2(..))")
	public void after() {
		System.out.println("after advice");
	}

	@AfterReturning("execution(* com.infy.service.Trial.p1(..))")
	public void afterReturning()  {
		System.out.println("After returning advice called.");
	}

//	@AfterThrowing(pointcut = "execution(* com.infy.service.Trial.s1(..))", throwing = "exception")
//	public void logAfterThrowingAdviceDetails(JoinPoint joinPoint, Exception exception) {
//		System.out.println("In After throwing Advice, Joinpoint signature :{}"+ joinPoint.getSignature());
//		System.out.println(exception.getMessage()+" "+exception);
//		
//	}
	
	@Around("execution(* com.infy.service.Trial.s1(..))")
	public Object aroundAdvice(ProceedingJoinPoint joinPoint) throws Throwable {
		System.out.println("Before proceeding part of the Around advice.");
		 Object cust =  joinPoint.proceed();
		System.out.println("After proceeding part of the Around advice.");
		return cust;
	}
	


}