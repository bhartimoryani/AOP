package com.infy;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.core.env.Environment;


import com.infy.service.*;
@SpringBootApplication
public class DemoSpringBootCoreApplication {

	
	
	public static void main(String[] args) throws Exception  {
		Trial service = null;
		AbstractApplicationContext context = (AbstractApplicationContext) SpringApplication.run(DemoSpringBootCoreApplication.class,
				args);
		service = (Trial) context.getBean("trial");
		service.s1();
		context.close();
	}

	

}