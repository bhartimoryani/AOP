package com.infy.service;

import org.springframework.stereotype.Service;

@Service("trial")
public class Trial {
	int avg;
	public void m1() {
		System.out.println("inside m1");
	}
	
	public void m2() {
		System.out.println("inside m2");
	}
	
	public void p1() {
		int a=10/2;
		System.out.println("inside p1");
	}
	
	public void s1() throws Exception{
		System.out.println("inside s1");
		 avg= 10/0;
		 
		
		
	}

}
